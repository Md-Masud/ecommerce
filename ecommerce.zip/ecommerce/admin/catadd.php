﻿
<?php
require_once '../vendor/autoload.php';
Session::inti();
Session::checksSession();
?>
<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
  include_once "adminClass/category.php";
 $cat=new category();
 if(isset($_POST['submit']))
 {
    $cd=$cat->catadd($_POST);
 }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Add New Category</h2>
                <?php
                if(isset($cd))
                {
                    echo $cd;
                }
                ?>
               <div class="block copyblock"> 
                 <form method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" placeholder="Enter Category Name..." class="medium" name="cName" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>