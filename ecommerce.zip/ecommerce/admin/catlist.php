﻿
<?php
require_once '../vendor/autoload.php';
Session::inti();
Session::checksSession();

?>
<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
                <?php
                include_once "adminClass/category.php";
                     $cat=new category();
                     if (isset($_GET['catdelete'])) {
                     	$id=$_GET['catdelete'];
                     	$cd=$cat->cdelete($id);
                     }
                if(isset($cd))
                {
                    echo $cd;
                }
                ?>
                <div class="block">        
                    <table class="data display datatable" id="example">

					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Category Name</th>
							<th>Action</th>
						</tr>
                    </thead>
					<tbody>
						<?php

                     $cl=$cat->catlist();
                     $i=0;
                      foreach ($cl as $data) {
                      	$i++
                    ?>
						<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><?php echo$data['cName'];?></td>
							<td><a href="catedit.php?id=<?php echo $data['id']?>">Edit</a> || <a href="?catdelete=<?php echo $data['id']?>">Delete</a></td>
						</tr>
						<?php } ?>
					</tbody>
				</table>

               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<?php include 'inc/footer.php';?>

