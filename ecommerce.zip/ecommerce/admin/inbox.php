﻿<?php
require_once "../vendor/autoload.php";
 include_once "adminClass/cat.php";
Session::inti();
Session::checksSession();
?>
<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
	$c= new cat();
  if(isset($_GET['id']))
 {
 	$id =$_GET['id'];
 	$status =$_GET['status'];
 	$or=$c->ordercomfrom($id,$status);

 }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Product Name</th>
							<th>Quantity</th>
							<th>Price</th>
							<th>UId</th>
							<th>Adress</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$c= new cat();
						$op=$c-> getorder();
						foreach ($op as $data) {
						?>
						<tr class="odd gradeX">
							<td><?php echo $data['pid'];?></td>
							<td><?php echo $data['pname'];?></td>
						
							<td><?php echo $data['quantity'];?></td>
							<td><?php echo  $data['price'];?></td>
							<td><?php echo $data['id'];?></td>
							</td>
							<td><a href="customer.php?cid=<?php echo $data['id']?>">Address</a></td>
							<?php if($data['status']=='0')
							{
							?>
							<td><a href="?id=<?php echo $data['oid'];?> & status=<?php echo $data['status'];?>">shift</a></td>
						</tr>
					<?php } else {?>
						<td><a href="?id=<?php echo $data['oid'];?>And stat=<?php echo $data['status']?>">Remove</a></td>
						</tr>
					<?php }?>
						<?php }?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
