<?php

require_once "../vendor/autoload.php";
require_once 'adminClass/login.php';
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<?php
$admin=new admin();
if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['logi'])) {
               $log=$admin->login($_POST);
           }
?>
<body>
<div class="container">
	<section id="content">
		<form action="" method="post">
			<h1>Admin Login</h1>
			<?php
			if(isset($log))
			{
				echo $log;
			}
			?>
			<div>
				<input type="text" placeholder="UserUser" required="" name="admin"/>
			</div>
			<div>
				<input type="password" placeholder="Password" required="" name="password"/>
			</div>
			<div>
				<input type="submit" value="Log in" name="logi"/>
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="#">Training with live project</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>