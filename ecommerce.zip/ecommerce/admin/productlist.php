﻿<?php
require "../vendor/autoload.php";
Session::inti();
Session::checksSession();
?>
<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
    
    include_once "adminClass/category.php";
    include_once "adminClass/brand.php";
    include_once "adminClass/product.php";
 ?>
<?php
$h=new Format();
$p=new product();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$pd=$p->productdelete($id);
}
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Post List</h2>
        <div class="block"> 
        <?php
        if(isset($pd))
        {
        	echo $pd;
        }
        ?> 
            <table class="data display datatable" id="example">
			<thead>
				<tr>
					<th>SI</th>
					<th>Product Name</th>
					<th>Category</th>
					<th>Brand</th>
					<th>Description</th>
					<th>Price</th>
					<th>Image</th>
					<th>Type</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$pl=$p->productlist();
				$i=0;
				foreach ($pl as $data) {
					$i++
				?>
				<tr class="odd gradeX">
					<td><?php echo  $i; ?></td>
					<td><?php echo  $data['pname']; ?></td>
					<td><?php echo  $data['cName']; ?></td>
					<td><?php echo  $data['bname']; ?></td>
					<td><?php echo  $h->textShorten($data['description']); ?></td>
					<td><?php echo  $data['price']; ?></td>
					<td><img src="<?php echo  $data['image']; ?>""height="40px" width="60px"></td>
					<td><?php   if($data['type']==0)
					{
						echo "Featured";
					}
                     else
                     {
                     	echo "Grenaral";
                     }
					 ?></td>
					<td><a href="">Edit</a> || <a href="?id=<?php echo $data['pid']?>">Delete</a></td>
				</tr>
			<?php }?>
			</tbody>
		</table>

       </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
