<!DOCTYPE HTML>
	  <div class="clear"></div>
  </div>	
  <?php
require_once 'partials/header.php';
require_once("adminClass/cat.php");
require_once "vendor/autoload.php";
Session::inti();
?>
<?php
$ct=new cat();

?>
<?php
if(isset($_GET['id']))
{
	$caid=$_GET['id'];
	$cad=$ct->cartdelete($caid);
}
?>
 <div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">
			    	<h2>Your Cart</h2>
						<table class="tblone">
							<tr>
								<th width="5%">SL</th>
								<th width="20%">Product Name</th>
								<th width="10%">Image</th>
								<th width="15%">Price</th>
								<th width="25%">Quantity</th>
								<th width="20%">Total Price</th>
								<th width="10%">Action</th>
							</tr>
							<?php
							$i=0;
							$sum=0;
							$ctv=$ct->catview();
							foreach ($ctv as $data) {
								$i++
							?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $data['pname'];?></td>
								<td><img src="admin/<?php echo  $data['image'];?>"alt=""/></td>
								<td><?php echo $data['price']?></td>
								<td>
									<?php
									if(isset($_POST['submit']))
									{
                                    $cap=$ct->catupdate($_POST);
									}
									?>
									<form action="" method="post">
										<input type="hidden" name="caid" value="<?php echo $data['caid'];?>"/>
										<input type="number" name="quantity" value="<?php echo $data['quantity'];?>"/>
										<input type="submit" name="submit" value="Update"/>
									</form>
								</td>
								<td><?php 
								$tolal= $data['price']* $data['quantity'];
								echo $tolal;
								$sum+= $tolal;
								?></td>
								<td><a href="?id=<?php echo $data['caid'] ;?>">X</a></td>
							</tr>
							<?php }?>
							
						</table>
						<table style="float:right;text-align:left;" width="40%">
							<tr>
								<th>Sub Total : </th>
								<td>TK.<?php echo $sum;?></td>
							</tr>
							<tr>
								<th>VAT : 10%</th>
								<td>TK. <?php $v=$sum*0.1;
								echo $v;
								 ?></td>
							</tr>
							<tr>
								<th>Grand Total :</th>
								<td><?php echo $t=$sum+$v?> </td>
								<?php
							     Session::set('sum',$t);
								?>
							</tr>
					   </table>
					</div>
					<div class="shopping">
						<div class="shopleft">
							<a href="index.php"> <img src="images/shop.png" alt="" /></a>
						</div>
						<div class="shopright">
							<a href="payment.php"> <img src="images/check.png" alt="" /></a>
						</div>
					</div>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>

   <?php
require_once 'partials/footer.php';
?>
</div>
</html