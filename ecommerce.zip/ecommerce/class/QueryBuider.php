<?php
 interface DB
{
  public function insert();

  public function all();

  public function find();

  public function update();

  public function delete();
} 

 class QueryBuider implements  DB
 {
 
   public function insert()
   {

   
   }

   public function all()
   {
    
   }

   public function find()
   {

   }

   public function update()
   {
    echo " live my country";
   }

   public function delete()
   {

   }
 }
 $n=new QueryBuider();
 $n->update();
 var_dump($n);
?>