<?php
interface DB
{
  public function insert($table,$data);
   
  public function selectAll($table);


  public function update($table,$data,$id);

  public function delet($table);
} 

 class mysql implements  DB
 {
        private $host = 'localhost'; //HOST NAME.
        private $db_name = 'ecomm'; //Database Name
        private $db_username = 'root'; //Database Username
        private $db_password = ''; //Database Password
        public  $connection;
  
  public function __construct()

   {
    try {
        $this->connection = new PDO('mysql:host='. $this->host .';dbname='.$this->db_name, $this->db_username, $this->db_password);
        $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

       } catch (PDOException $e) {
      echo 'Connection failed: ' . $e->getMessage();
       }

   }
   public function insert($table,$data)
   {

    $placeholder=[];
    foreach ($data as $key => $value) {
      $placeholder[]=':'.$key;
    }

    $sql='INSERT INTO '.$table.' ('.implode(',', array_keys($data)).')VALUES('.implode(',', $placeholder).')';
    $query=$this->connection->prepare($sql);

     foreach ($data as $placeholder => $val) {
       $query->bindvalue(':'.$placeholder,$val);
       
     }
     
     return $query->execute();
   }

   
   public function selectAll($table)
   {
     $sql="SELECT * FROM ".$table ;
     
    $query=$this->connection->prepare($sql);
      $query->execute();
      $result=$query->fetchAll();
      return $result;
   }


   public function update($table,$data,$id)
   {
  

    $placeholder=[];
    foreach ($data as $key => $value) {
      $placeholder[]="{'$key'}=:{$key}";
    }
    
    $place=[];
    foreach ($id as $key => $value) {
      $place[]="{'$key'}=:{$key}";
    }
  

    $sql='UPDATE '.$table."SET".implode(',', $placeholder);
    $sql.=" WHERE " .implode(',', $place);

    $query=$this->connection->prepare($sql);

     foreach ($data as $placeholder => $val) {
       $query->bindvalue(':'.$placeholder,$val);
       
     }

     foreach ($id as $placeholder => $vall) {
       $query->bindvalue(':'.$place,$vall);
       
     }
       
     $query.=$query;
     var_dump($query);
     return $query->execute();
   }
   

   public function delet($table)
   {
    
   }
}


?>