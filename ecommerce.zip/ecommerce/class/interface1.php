
<?php
interface InterfaceName {
  public function insert();

  public function all();

  public function find();

  public function update();

  public function delete();
}
?>