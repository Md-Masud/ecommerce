<?php
include_once "session.php";
include_once 'database.php';

class user 
{
	private $da;
	public function __construct()
	{
		$this->da =new mysql();
	}
	public function registation($data)
	{
      $name=trim($data['name']);
      $zipcode=trim($data['zipcode']);
      $email=trim($data['email']);
      $address=trim($data['address']);
      $phone=trim($data['phone']);
      $password=trim($data['password']);
      $result=$this->da->insert('reg',[
        'name'=>$name,
        'zipcode'=>$zipcode,
        'email'=>$email,
        'address'=>$address,
        'phone'=>$phone,
        'password'=>password_hash($password, PASSWORD_BCRYPT),
      ]);
	
	if($result)
		{
			$msg="<div class='alert alert-success'><strong>Success</strong> insert successfull</div>";
			 header("location: index.php");
		}
		else
		{

		$msg="<div class='alert alert-danger'><strong>Error!</strong> insetr not successfull exit</div>";
			return $msg;	
		}
		
   }
   
	public function login($data)
	{
		$email=$data['email'];
		$password=$data['password'];
		if($email==''||$password=='')
		{
			$msg="<div class='alert alert-danger'><strong>Error!</strong>field not emty</div>";
			
			return $msg;
		}
		if(filter_var($email,FILTER_VALIDATE_EMAIL===false))
		{
			$msg="<div class='alert alert-danger'><strong>Error!</strong> you must email</div>";
			return $msg;
		}
		
		$result=$this->userlogin($email,$password);
		if($result)
		{
         Session::inti();
         session::set("login" ,true);
         Session::set('id',$result->id);
         Session::set('name',$result->name);
         Session::set('email',$result->email);
         Session::set('loginmsg',$result->email);
        Session::set('loginmsg',"<div class='alert alert-success'><strong>Success</strong> login successfull</div>");
         header("location: index.php");
		}
		else
		{
			$msg="<div class='alert alert-danger'><strong>Error!</strong> data not found</div>";
			return $msg;
		}
	}
     public function userlogin($email,$password)
	   {
        $sql="SELECT * FROM reg WHERE email=:email AND password=:password";
        $query=$this->da->connection->prepare($sql);
        $query->bindValue(':email',$email);
        $query->bindValue(':password',$password);
        $query->execute();
        $result=$query->fetch(PDO::FETCH_OBJ);
        return $result;
	   } 
	 public function userview()
	 {
	 	$id = Session::get('id');
	 	$sql="SELECT * FROM reg WHERE id=:id";
        $query=$this->da->connection->prepare($sql);
        $query->bindValue(':id',$id);
        $query->execute();
        $result=$query->fetchAll();
        return $result;
	 }
	
}



?>