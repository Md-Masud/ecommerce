<!DOCTYPE HTML>
<?php
require_once 'partials/header.php';

?>
<?php
        	require_once "vendor/autoload.php";
        	 $user=new user();
                 if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['logi'])) {
               $log=$user->login($_POST);
           }
        	?>
<br>
<style type="text/css">
input[type=text], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
</style>
 <div class="mainn">
    <div class="contentt">
    	<?php
    	if(isset($log))
    	{
    		echo $log;
    	}
    	?>
            <div style="border: 1px solid black; margin: auto; text-align: center; width: 500px; height: 300px;">
    	
        	<h3 style="font-size: 30px;color:green; font-weight: bold;" >Existing Customers</h3>
        	<br>
        	<p style="font-size: 20px;color:green; font-weight: bold;">Sign in with the form below.</p>
        	<form action="" method="post">
                <label style="font-size: 20px;color:green; font-weight: bold; margin: 10px;  "> User Email</label>
                	<input style="margin: 20px; width: 250px; height: 30px; font-size: 20px;" type='email' name="email" >

                	<label style="font-size: 20px;color:green; font-weight: bold; margin: 10px; "> Password</label>
                    <input style="margin: 20px; width: 250px; height: 30px; font-size: 20px; " type='password' name="password" >
                   
                   <button style="font-size: 20px;color:green; font-weight: bold; margin: 10px; " type="submit" class="btn btn-primary" name="logi">Submit</button>
              </form>

        </div>
        </div>
        </fieldset>
    </div>
    <br>
    <?php
require_once 'partials/footer.php';
?>
  </html>
 

